# HMAILZ Multiplayer Server — first City Life room

This is the first server component for HMAILZ Games. It uses Colyseus rooms and state synchronization.

## What this first version provides

- One shared `hmailz_city` room, up to 20 connected players.
- Player records with username, position (x/y/z), rotation, and avatar color.
- Position updates sent by clients and synchronized to everyone in the room.
- Room chat and join/leave notices.
- Basic input bounds checks.

## Important status

This is the **server starter**, not the completed multiplayer game yet. The existing HMAILZ HTML file still needs its client-side Colyseus connection added. Until that client integration is installed and the server is deployed, the profile Join button will still be a demo.

The first prototype accepts display names from clients. Before public launch, connect Supabase authentication to server-side room authentication and add stricter movement validation/rate limits.

## Deploy

1. Upload this folder's contents to a new GitHub repository named `hmailz-multiplayer-server`.
2. In Render, create a new **Web Service** and connect that repository.
3. Render can use the included `render.yaml`; otherwise set:
   - Build command: `npm install && npm run build`
   - Start command: `npm start`
   - Node version: `20` or newer
4. After deployment, copy the service URL, for example `https://YOUR-SERVICE.onrender.com`.
5. Keep that URL. It will be added to the HMAILZ HTML client in the next integration step.

## Local test (requires Node.js 20+)

```bash
npm install
npm run dev
```

The Colyseus server listens on port 2567. The browser-based Colyseus Playground is available at the service root when supported by the server transport.

## Room protocol

- Room name: `hmailz_city`
- Join options: `{ username: "PlayerName", color: "#248bff" }`
- Client message `move`: `{ x, y, z, rotation }`
- Client message `chat`: `{ text: "Hello!" }`
- Broadcast `city-chat`: `{ name, text, at }`
- Broadcast `system`: join/leave text

## Security

Never put a Supabase service-role key, database password, or other server secret in the HTML file or GitHub Pages repository. Only public client keys belong in browser code. Supabase user-token verification must happen on the server before treating a player as a signed-in account.
