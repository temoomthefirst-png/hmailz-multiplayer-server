import { Client, Room } from "colyseus";
import { schema, t } from "@colyseus/schema";

const CityPlayer = schema({
  name: t.string(),
  x: t.number(),
  y: t.number(),
  z: t.number(),
  rotation: t.number(),
  color: t.string()
}, "CityPlayer");

const CityState = schema({
  players: t.map(CityPlayer)
}, "CityState");

type MoveInput = {
  x?: number;
  y?: number;
  z?: number;
  rotation?: number;
};

function safeNumber(value: unknown, fallback: number, min: number, max: number) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(min, Math.min(max, n));
}

export class CityRoom extends Room {
  maxClients = 20;
  state = new CityState();

  messages = {
    move: (client: Client, input: MoveInput) => {
      const player = this.state.players.get(client.sessionId);
      if (!player || !input || typeof input !== "object") return;

      // Basic server-side bounds checking. Full movement authority/anti-cheat
      // will be added after the first two-client connection test.
      player.x = safeNumber(input.x, player.x, -500, 500);
      player.y = safeNumber(input.y, player.y, -10, 100);
      player.z = safeNumber(input.z, player.z, -500, 500);
      player.rotation = safeNumber(input.rotation, player.rotation, -1000, 1000);
    },

    chat: (client: Client, input: { text?: string }) => {
      const player = this.state.players.get(client.sessionId);
      const message = String(input?.text ?? "").trim().slice(0, 120);
      if (!player || !message) return;
      this.broadcast("city-chat", {
        name: player.name,
        text: message,
        at: Date.now()
      });
    }
  };

  onJoin(client: Client, options: { username?: string; color?: string }) {
    const name = String(options?.username ?? "Player").trim().slice(0, 20) || "Player";
    const color = /^#[0-9a-fA-F]{6}$/.test(String(options?.color ?? ""))
      ? String(options.color)
      : "#248bff";

    this.state.players.set(client.sessionId, new CityPlayer({
      name,
      x: 0,
      y: 0,
      z: 5,
      rotation: 0,
      color
    }));
    this.broadcast("system", `${name} joined HMAILZ City.`);
  }

  onLeave(client: Client) {
    const player = this.state.players.get(client.sessionId);
    const name = player?.name ?? "A player";
    this.state.players.delete(client.sessionId);
    this.broadcast("system", `${name} left HMAILZ City.`);
  }
}
