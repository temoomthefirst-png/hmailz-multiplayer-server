import { defineRoom, defineServer } from "colyseus";
import { CityRoom } from "./rooms/CityRoom.js";

const port = Number(process.env.PORT ?? 2567);

const server = defineServer({
  rooms: {
    // All City Life players join the same public room for this first test.
    hmailz_city: defineRoom(CityRoom)
  }
});

server.listen(port);
console.log(`HMAILZ Multiplayer server listening on port ${port}`);
